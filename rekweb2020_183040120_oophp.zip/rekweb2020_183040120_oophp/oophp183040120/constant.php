<?php 

// define('NAMA', 'Muhamad Aswin');

// echo NAMA;

// echo "<br>";
// //cara ke-2

// const UMUR = 23;
// echo UMUR;


// class Coba{
// 	const NAMA = 'Muhamad Aswin;
// }

// echo Coba::NAMA;
// echo "<hr>";

//  echo __LINE__;
//  echo "<br>";
//  echo __FILE__;
//  echo "<br>";

//  function coba(){
//  	return __FUNCTION__;
//  }

// echo coba();
// echo "<br>";

class Coba{
	public $kelas = __CLASS__;
}


$obj = new Coba;
echo $obj->kelas;


 ?>