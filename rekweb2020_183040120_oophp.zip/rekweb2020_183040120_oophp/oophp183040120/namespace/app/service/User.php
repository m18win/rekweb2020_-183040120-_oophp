<?php namespace app\service;

class User {
	public function __construct() {
		echo "ini adalah class " . __CLASS__;
	}
}
