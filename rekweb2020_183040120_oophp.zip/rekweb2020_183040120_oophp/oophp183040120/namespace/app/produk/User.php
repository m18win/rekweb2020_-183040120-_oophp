<?php namespace app\produk;

class User {
	public function __construct() {
		echo "ini adalah class " . __CLASS__;
	}
}
