<?php 	
interface InfoProduk {
		public function getinfoProduk();
}