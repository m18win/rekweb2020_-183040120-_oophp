<?php 


class Coba {

}


$a = new Coba();
$b = new Coba();
$c = new Coba();

var_dump($a);
echo "<br>";
var_dump($b);
echo "<br>";
var_dump($c);

//183040120